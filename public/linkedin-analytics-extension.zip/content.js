// Content script: runs on linkedin.com, exposes LinkedIn Voyager API access
// to the extension via chrome.runtime messages. All data stays local.
(() => {
  "use strict";

  const API_URL = "https://www.linkedin.com/voyager/api";
  const GRAPHQL_URL = "https://www.linkedin.com/voyager/api/graphql";

  // GraphQL query IDs reverse-engineered from LinkedIn's web client.
  // These can rotate over time — update if requests start 4xx-ing.
  const QUERY_ID_ME =
    "voyagerIdentityDashProfiles.34ead06db82a2cc9a778fac97f69ad6a";
  const QUERY_ID_ANALYTICS =
    "voyagerFeedDashCreatorExperienceDashboard.6fcd24af6f10cdcd1cd7d8e747df3276";
  const QUERY_ID_FOLLOWING =
    "voyagerSearchDashClusters.15c671c3162c043443995439a3d3b6dd";
  const QUERY_ID_POSTS =
    "voyagerFeedDashProfileUpdates.80d5abb3cd25edff72c093a5db696079";

  function getCookie(name) {
    const m = document.cookie
      .split("; ")
      .find((c) => c.startsWith(name + "="));
    return m ? m.split("=").slice(1).join("=") : null;
  }

  function getCsrfToken() {
    const j = getCookie("JSESSIONID");
    return j ? j.replace(/['"]+/g, "") : null;
  }

  async function voyagerGet(url) {
    const csrf = getCsrfToken();
    const headers = { "Content-Type": "application/json" };
    if (csrf) headers["Csrf-Token"] = csrf;
    const res = await fetch(url, {
      method: "GET",
      credentials: "include",
      headers,
    });
    if (!res.ok) {
      const bodyText = await res.text().catch(() => "");
      const tail = bodyText ? " — " + bodyText.slice(0, 200) : "";
      throw new Error("HTTP " + res.status + " " + url.replace(/^https?:\/\/[^/]+/, "") + tail);
    }
    return res.json();
  }

  async function voyagerGetFirstWorking(urls) {
    let lastErr;
    for (const url of urls) {
      try { return { url, data: await voyagerGet(url) }; }
      catch (e) { lastErr = e; }
    }
    throw lastErr || new Error("All endpoints failed");
  }

  async function getMe(vanity = "me") {
    const url = `${GRAPHQL_URL}?variables=(vanityName:${encodeURIComponent(
      vanity
    )})&queryId=${QUERY_ID_ME}`;
    return voyagerGet(url);
  }

  async function getAnalytics() {
    const url = `${GRAPHQL_URL}?includeWebMetadata=false&queryId=${QUERY_ID_ANALYTICS}`;
    return voyagerGet(url);
  }

  async function getConnections() {
    const url = `${API_URL}/search/dash/clusters?decorationId=com.linkedin.voyager.dash.deco.search.SearchClusterCollection-1&count=0&origin=Communities&q=all&query=(queryParameters:(resultType:List(CONNECTIONS)),flagshipSearchIntent:MYNETWORK_CURATION_HUB)&start=0`;
    return voyagerGet(url);
  }

  async function getFollowing() {
    const url = `${GRAPHQL_URL}?includeWebMetadata=false&variables=(start:0,count:10,origin:CurationHub,query:(flagshipSearchIntent:MYNETWORK_CURATION_HUB,includeFiltersInResponse:true,queryParameters:List((key:resultType,value:List(PEOPLE_FOLLOW)))))&queryId=${QUERY_ID_FOLLOWING}`;
    return voyagerGet(url);
  }

  // ---- Company / Organization (admin) endpoints ----------------------------
  // Legacy REST endpoints — more stable than rotating GraphQL queryIds.

  // LinkedIn removed the viewerOrganizations admin-list REST endpoint. We now
  // look up companies by universalName (the slug after /company/ in the URL)
  // using the SAME endpoint your own browser hits when you view that company
  // page — zero abnormal traffic, looks like normal browsing.
  async function getCompanyByUniversalName(universalName) {
    const url = `${API_URL}/organization/companies?q=universalName&universalName=${encodeURIComponent(universalName)}`;
    return voyagerGet(url);
  }

  async function getCompaniesByUniversalNames(universalNames) {
    const results = await Promise.allSettled(
      universalNames.map(async (name) => {
        const resp = await getCompanyByUniversalName(name);
        const el = resp?.elements?.[0] || resp?.data?.elements?.[0];
        if (!el) return null;
        const urn = el?.entityUrn || "";
        const id = String(urn).split(":").pop();
        const logoVec =
          el?.logo?.image?.["com.linkedin.common.VectorImage"] ||
          el?.logoV2?.original || null;
        const root = logoVec?.rootUrl || "";
        const arts = logoVec?.artifacts || [];
        const art = arts.find((a) => a.width >= 100) || arts[0];
        const logoUrl = art && root ? root + art.fileIdentifyingUrlPathSegment : "";
        return {
          id,
          universalName: name,
          name: el?.name || el?.localizedName || name,
          followerCount: el?.followingInfo?.followerCount || el?.followerCount || null,
          staffCount: el?.staffCount || null,
          tagline: el?.tagline || el?.description?.text || "",
          logoUrl,
        };
      })
    );
    return results.map((r, i) => {
      if (r.status === "fulfilled" && r.value) return r.value;
      return { universalName: universalNames[i], error: r.status === "rejected" ? String(r.reason?.message || r.reason) : "Not found" };
    });
  }

  async function getPosts(publicId, count = 50) {
    const variables = `(count:${count},start:0,profileUrn:${encodeURIComponent(
      "urn:li:fsd_profile:" + publicId
    )})`;
    const url = `${GRAPHQL_URL}?includeWebMetadata=false&variables=${variables}&queryId=${QUERY_ID_POSTS}`;
    return voyagerGet(url);
  }

  function extractProfile(meResponse) {
    const el =
      meResponse?.data?.identityDashProfilesByMemberIdentity?.elements?.[0];
    if (!el) return null;
    const publicId = (el.entityUrn || "").split(":").pop();
    const vec =
      el.profilePicture?.displayImageReferenceResolutionResult?.vectorImage;
    const root = vec?.rootUrl || "";
    const arts = vec?.artifacts || [];
    const art =
      arts.find((a) => a.width >= 100 && a.height >= 100) || arts[0];
    const pic = art && root ? root + art.fileIdentifyingUrlPathSegment : "";
    return {
      firstName: el.firstName,
      lastName: el.lastName,
      headline: el.headline,
      publicIdentifier: el.publicIdentifier,
      publicId,
      location: el.geoLocation?.geo?.defaultLocalizedName || "",
      profilePictureUrl: pic,
    };
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    (async () => {
      try {
        switch (msg?.type) {
          case "ping":
            sendResponse({ success: true });
            return;
          case "getProfile": {
            const me = await getMe(msg.vanity || "me");
            const profile = extractProfile(me);
            if (!profile)
              return sendResponse({ success: false, error: "No profile" });
            sendResponse({ success: true, data: { profile, raw: me } });
            return;
          }
          case "getAll": {
            const me = await getMe();
            const profile = extractProfile(me);
            if (!profile)
              return sendResponse({ success: false, error: "No profile" });
            const [analytics, connections, following, posts] =
              await Promise.allSettled([
                getAnalytics(),
                getConnections(),
                getFollowing(),
                getPosts(profile.publicId, msg.postCount || 50),
              ]);
            sendResponse({
              success: true,
              data: {
                profile,
                analytics:
                  analytics.status === "fulfilled" ? analytics.value : null,
                connections:
                  connections.status === "fulfilled"
                    ? connections.value
                    : null,
                following:
                  following.status === "fulfilled" ? following.value : null,
                posts: posts.status === "fulfilled" ? posts.value : null,
                fetchedAt: Date.now(),
              },
            });
            return;
          }
          case "getAllCompanies": {
            const names = Array.isArray(msg.universalNames) ? msg.universalNames : [];
            if (names.length === 0) {
              return sendResponse({ success: false, error: "No company slugs configured. Add them in extension Settings → Tracked companies." });
            }
            const companies = await getCompaniesByUniversalNames(names);
            sendResponse({ success: true, data: { companies, fetchedAt: Date.now() } });
            return;
          }
          case "getPosts": {
            const me = await getMe();
            const profile = extractProfile(me);
            const posts = await getPosts(
              profile.publicId,
              msg.postCount || 50
            );
            sendResponse({ success: true, data: { profile, posts } });
            return;
          }
          default:
            sendResponse({ success: false, error: "Unknown message type" });
        }
      } catch (e) {
        sendResponse({ success: false, error: String(e?.message || e) });
      }
    })();
    return true; // async
  });

  console.log("[LI Personal Analytics] content script ready");
})();
