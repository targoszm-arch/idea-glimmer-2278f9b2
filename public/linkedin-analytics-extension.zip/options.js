"use strict";

const DEFAULT_API_URL = "https://rnshobvpqegttrpaowxe.supabase.co";
const $ = (id) => document.getElementById(id);

async function load() {
  const cfg = await chrome.storage.local.get(["apiUrl", "apiToken", "autoSync", "trackedCompanies"]);
  $("apiUrl").value = cfg.apiUrl || DEFAULT_API_URL;
  $("apiToken").value = cfg.apiToken || "";
  $("autoSync").checked = cfg.autoSync !== false;
  $("trackedCompanies").value = cfg.trackedCompanies || "";
}

async function save() {
  await chrome.storage.local.set({
    apiUrl: $("apiUrl").value.trim() || DEFAULT_API_URL,
    apiToken: $("apiToken").value.trim(),
    autoSync: $("autoSync").checked,
    trackedCompanies: $("trackedCompanies").value.trim(),
  });
  $("status").textContent = "Saved.";
}

async function test() {
  $("status").textContent = "Testing…";
  const url = ($("apiUrl").value.trim() || DEFAULT_API_URL) + "/functions/v1/linkedin-extension-sync";
  const token = $("apiToken").value.trim();
  if (!token) {
    $("status").textContent = "Enter a token first.";
    return;
  }
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
      body: JSON.stringify({ profile: { test: true, ts: Date.now() } }),
    });
    const body = await res.json().catch(() => ({}));
    if (res.ok && body.success) $("status").textContent = "✓ Connected. Test snapshot written.";
    else $("status").textContent = "✗ " + (body.error || `HTTP ${res.status}`);
  } catch (e) {
    $("status").textContent = "✗ " + String(e?.message || e);
  }
}

$("save").addEventListener("click", save);
$("test").addEventListener("click", test);
load();
