// Bridge between the ContentLab web app and this extension.
// ContentLab can postMessage to its own window; this script (running in the
// ContentLab page context) captures those messages and forwards them to the
// extension background worker. Replies are postMessaged back so the page can
// react (show "synced!" toast etc.).
//
// Protocol (page → extension):
//   window.postMessage({ source: "contentlab", type: "refresh-linkedin" }, "*")
//
// Protocol (extension → page):
//   { source: "contentlab-extension", type: "refresh-linkedin:done", ok: bool, error?, written? }
//   { source: "contentlab-extension", type: "ping:pong", version: "1.2.0" }

(() => {
  "use strict";

  window.addEventListener("message", async (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.source !== "contentlab") return;

    if (msg.type === "ping") {
      window.postMessage(
        { source: "contentlab-extension", type: "ping:pong", version: chrome.runtime.getManifest().version },
        "*"
      );
      return;
    }

    if (msg.type === "refresh-linkedin") {
      // Run profile + companies refresh, then push to ContentLab.
      const profileResp = await new Promise((r) => chrome.runtime.sendMessage({ type: "fetchAll", postCount: 50 }, r));
      const companiesResp = await new Promise((r) => chrome.runtime.sendMessage({ type: "fetchCompanies" }, r));
      window.postMessage(
        {
          source: "contentlab-extension",
          type: "refresh-linkedin:done",
          profile: { ok: !!profileResp?.success, error: profileResp?.error, sync: profileResp?.sync },
          companies: { ok: !!companiesResp?.success, error: companiesResp?.error, sync: companiesResp?.sync },
        },
        "*"
      );
    }
  });

  // Announce ourselves so the page can detect the extension is installed.
  window.postMessage(
    { source: "contentlab-extension", type: "available", version: chrome.runtime.getManifest().version },
    "*"
  );
})();
