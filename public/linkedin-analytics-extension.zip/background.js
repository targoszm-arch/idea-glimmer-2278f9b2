// Background service worker. Stores fetched LinkedIn data in chrome.storage.local.
// No external network calls — everything stays on the user's machine.
"use strict";

const STORAGE_KEY = "li_analytics_snapshot";
const DEFAULT_API_URL = "https://rnshobvpqegttrpaowxe.supabase.co";

async function pushToContentLab(payload) {
  const cfg = await chrome.storage.local.get(["apiUrl", "apiToken", "autoSync"]);
  if (cfg.autoSync === false) return { skipped: true };
  if (!cfg.apiToken) return { skipped: true, reason: "no token configured" };
  const url = (cfg.apiUrl || DEFAULT_API_URL) + "/functions/v1/linkedin-extension-sync";
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + cfg.apiToken },
      body: JSON.stringify(payload),
    });
    const body = await res.json().catch(() => ({}));
    return res.ok && body.success ? { success: true, written: body.written } : { success: false, error: body.error || `HTTP ${res.status}` };
  } catch (e) {
    return { success: false, error: String(e?.message || e) };
  }
}

async function getLinkedInTab() {
  const tabs = await chrome.tabs.query({ url: "*://*.linkedin.com/*" });
  return tabs[0] || null;
}

async function ensureLinkedInTab() {
  let tab = await getLinkedInTab();
  if (tab) return tab;
  tab = await chrome.tabs.create({
    url: "https://www.linkedin.com/feed/",
    active: false,
  });
  // Wait for the new tab to finish loading.
  await new Promise((resolve) => {
    const listener = (tabId, info) => {
      if (tabId === tab.id && info.status === "complete") {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, 15000);
  });
  return tab;
}

function sendToTab(tabId, msg) {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, msg, (resp) => {
      if (chrome.runtime.lastError) {
        resolve({ success: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(resp);
      }
    });
  });
}

async function injectContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"],
    });
    return true;
  } catch (e) {
    return false;
  }
}

async function sendToTabWithInjection(tabId, msg) {
  let resp = await sendToTab(tabId, msg);
  if (resp?.success === false && /Receiving end does not exist/i.test(resp.error || "")) {
    const ok = await injectContentScript(tabId);
    if (!ok) return { success: false, error: "Could not inject content script (open a LinkedIn tab manually and retry)" };
    // Give the script a moment to register its listener.
    await new Promise((r) => setTimeout(r, 300));
    resp = await sendToTab(tabId, msg);
  }
  return resp;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === "fetchAll") {
        const tab = await ensureLinkedInTab();
        if (!tab?.id)
          return sendResponse({ success: false, error: "No LinkedIn tab" });
        const resp = await sendToTabWithInjection(tab.id, {
          type: "getAll",
          postCount: msg.postCount || 50,
        });
        if (resp?.success) {
          await chrome.storage.local.set({ [STORAGE_KEY]: resp.data });
          const push = await pushToContentLab({ profile: resp.data });
          resp.sync = push;
        }
        sendResponse(resp);
        return;
      }
      if (msg.type === "fetchCompanies") {
        const tab = await ensureLinkedInTab();
        if (!tab?.id) return sendResponse({ success: false, error: "No LinkedIn tab" });
        const cfg = await chrome.storage.local.get("trackedCompanies");
        const raw = String(cfg.trackedCompanies || "").trim();
        if (!raw) {
          return sendResponse({ success: false, error: "No companies configured. Right-click the extension → Options → Tracked companies." });
        }
        // Parse: accept full URLs or bare slugs, one per line or comma-separated.
        const universalNames = raw
          .split(/[\n,]+/)
          .map((s) => s.trim())
          .filter(Boolean)
          .map((s) => {
            const m = s.match(/linkedin\.com\/(?:company|school|showcase)\/([^/?#]+)/i);
            return m ? m[1] : s.replace(/^https?:\/\//i, "").replace(/^\/+|\/+$/g, "");
          });
        const resp = await sendToTabWithInjection(tab.id, { type: "getAllCompanies", universalNames });
        if (resp?.success) {
          await chrome.storage.local.set({ li_analytics_companies: resp.data });
          const push = await pushToContentLab({ companies: resp.data?.companies || [] });
          resp.sync = push;
        }
        sendResponse(resp);
        return;
      }
      if (msg.type === "getCompaniesSnapshot") {
        const data = await chrome.storage.local.get("li_analytics_companies");
        sendResponse({ success: true, data: data.li_analytics_companies || null });
        return;
      }
      if (msg.type === "getSnapshot") {
        const data = await chrome.storage.local.get(STORAGE_KEY);
        sendResponse({ success: true, data: data[STORAGE_KEY] || null });
        return;
      }
      if (msg.type === "clear") {
        await chrome.storage.local.remove([STORAGE_KEY, "li_analytics_companies"]);
        sendResponse({ success: true });
        return;
      }
      sendResponse({ success: false, error: "Unknown message type" });
    } catch (e) {
      sendResponse({ success: false, error: String(e?.message || e) });
    }
  })();
  return true;
});

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.tabs.create({ url: chrome.runtime.getURL("popup.html") });
  }
});
